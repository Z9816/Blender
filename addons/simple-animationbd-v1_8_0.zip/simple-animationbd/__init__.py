# SPDX-License-Identifier: GPL-3.0-or-later

bl_info = {
    "name": "Simple Animation Graph",
    "blender": (4, 2, 0),
    "category": "Animation",
    "author": "Dédouze, Samuel Bernou",
    "version": (1, 8, 0),
    "description": "Animate by drawing trajectories on the screen!",
}

from . import properties
from . import panel
from . import operators
from . import gizmo
from . import preferences

modules = (
    properties,
    operators,
    preferences,
    gizmo,
    panel,
)

if "bpy" in locals():
    import importlib
    for module in modules:
        importlib.reload(module)

import bpy

def register():
    bpy.types.WindowManager.simple_animation_preview_countdown = bpy.props.FloatProperty(default=0.0)

    for module in modules:
        module.register()

def unregister():
    del bpy.types.WindowManager.simple_animation_preview_countdown

    for module in reversed(modules):
        module.unregister()

if __name__ == "__main__":
    register()
