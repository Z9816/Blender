import bpy

class preview_axis_operator(bpy.types.Operator):
    """Preview the animation axes"""
    bl_idname = "object.preview_axis_operator"
    bl_label = "Preview Axis"
    bl_description = "Temporarily show the axis gizmos for 3 seconds"

    _timer = None
    _countdown = 2

    def modal(self, context, event):
        if event.type == 'TIMER':
            context.window_manager.simple_animation_preview_countdown -= 0.1

            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

            if context.window_manager.simple_animation_preview_countdown <= 0:
                self.hide_gizmos(context)
                context.window_manager.event_timer_remove(self._timer)
                return {'FINISHED'}
            return {'PASS_THROUGH'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        props = context.scene.simple_animation_props

        if not (props.use_x or props.use_y or props.use_z):
            self.report({'ERROR'}, "Pick at least one of X Y or Z to save keyframes")
            return {'CANCELLED'}

        props.show_gizmos = True

        # Force a redraw of the 3D viewport
        context.window_manager.simple_animation_preview_countdown = 3.0  # Set the countdown to 3 seconds

        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

        # stop the timer if it already started
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
        # Start the timer
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def hide_gizmos(self, context):
        props = context.scene.simple_animation_props
        props.show_gizmos = False

        # Force a redraw of the 3D viewport
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

# Register and Unregister Functions
def register():
    bpy.utils.register_class(preview_axis_operator)

def unregister():
    bpy.utils.unregister_class(preview_axis_operator)
