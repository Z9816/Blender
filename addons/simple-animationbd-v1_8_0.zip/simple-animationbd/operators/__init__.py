from . import (
            anim_operator,
            curve_path,
            preview_axis_operator,
            )

modules = (
    anim_operator,
    curve_path,
    preview_axis_operator,
)

if "bpy" in locals():
    import importlib
    for module in modules:
        importlib.reload(module)

def register():
    for module in modules:
        module.register()

def unregister():
    for module in reversed(modules):
        module.unregister()