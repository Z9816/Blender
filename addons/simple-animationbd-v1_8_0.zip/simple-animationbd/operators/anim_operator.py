import bpy
import math
from mathutils import Quaternion, Vector
from .. import utils
from ..drawings import get_processed_trajectory_points
from ..constants import CURVE_NAME
from .curve_path import restore_previous_selection

class OBJECT_OT_simple_animation_operator(bpy.types.Operator):
    bl_idname = "object.simple_animation_operator"
    bl_label = "Run Simple Animation"
    bl_options = {"REGISTER", "UNDO"}

    animation_type : bpy.props.EnumProperty(
        name="Animation Type",
        description="Choose whether to animate position or rotation",
        items=(
            ('POSITION', "Position", "Animate object position", 0),
            ('ROTATION', "Rotation", "Animate object rotation", 1)
        ),
        default="POSITION"
    )

    @classmethod
    def poll(cls, context):
        if not context.active_object:
            cls.poll_message_set("An object must be active")
            return False
        if not utils.active_annotation_frame_poll(context) and not context.scene.objects.get(CURVE_NAME):
            cls.poll_message_set("Draw a trajectory with the annotation first")
            return False
        return True

    @classmethod
    def description(cls, context, properties):
        if properties.animation_type == 'POSITION':
            return "Animate the object's position along the drawn trajectory"
        else:
            return "Animate the object's rotation according to drawn trajectory"

    def execute(self, context):
        scene = context.scene
        obj = context.active_object
        props = scene.simple_animation_props

        if not obj:
            self.report({'ERROR'}, "No active object selected.")
            return {'CANCELLED'}

        ## In case we are on curve:
        ## restore previous selection and active object before continuing
        if obj.name == CURVE_NAME:
            obj = restore_previous_selection(context)
            ## Cancel if no active object restored
            if not obj:
                self.report({'ERROR'}, "No active object selected.")
                return {'CANCELLED'}                

        is_bone_mode = obj.type == 'ARMATURE' and context.mode == 'POSE'
        bone = None

        if not (props.use_x or props.use_y or props.use_z):
            self.report({'ERROR'}, "Pick at least one of X Y or Z to save keyframes")
            return {'CANCELLED'}

        if is_bone_mode:
            bone = context.active_pose_bone
            if not bone:
                self.report({'ERROR'}, "No active bone in Pose Mode.")
                return {'CANCELLED'}

        insert_auto_mode = scene.tool_settings.use_keyframe_insert_auto
        target = bone if is_bone_mode else obj

        # Get and process trajectory points
        sorted_intersection_points = get_processed_trajectory_points(context, self.animation_type)
        
        if isinstance(sorted_intersection_points, str):
            self.report({'ERROR'}, sorted_intersection_points)
            return {'CANCELLED'}

        keyframe_duration = props.keyframe_step if props.timing == 'by_step' else max(1, math.ceil(props.frames_duration / (len(sorted_intersection_points)-1)))
        current_frame = scene.frame_current

        ## Backup all current keyframes to change type for next ones
        source_ob = target.id_data if isinstance(target, bpy.types.PoseBone) else target
        current_keys = []
        if source_ob.animation_data and source_ob.animation_data.action:
            current_keys = [(fc.data_path, fc.array_index, k.co.x) for fc in source_ob.animation_data.action.fcurves for k in fc.keyframe_points]

        ## Store initial matrix
        init_matrix = target.matrix.copy() if is_bone_mode else target.matrix_world.copy()

        if is_bone_mode:
            current_position = source_ob.matrix_world @ init_matrix.to_translation()
        else:
            current_position = init_matrix.to_translation() # <- object's target.matrix_world.translation

        if self.animation_type == 'POSITION':

            ## / Rotation keys
            if props.orient_to_trajectory and len(sorted_intersection_points) > 1:
                ## Ensure autokey is off for rotation keying (restored later)
                scene.tool_settings.use_keyframe_insert_auto = False
                store_list = []
                override = {}

                ## Init variables for rotation setup
                if is_bone_mode:
                    # Bone
                    initial_vector = (sorted_intersection_points[1] - sorted_intersection_points[0]).normalized()
                    current_world_matrix = (source_ob.matrix_world @ target.matrix).copy()
                    store_list = [(pb.bone, 'select', False) for pb in context.selected_pose_bones if pb != target]
                    store_list.append((target.bone, 'select', True)) # ensure active is selected
                else:
                    # Object
                    initial_vector = (sorted_intersection_points[1] - sorted_intersection_points[0]).normalized()
                    current_world_matrix = target.matrix_world.copy()
                    override = {'selected_objects': [target]}

                world_pivot = current_world_matrix.to_translation()
                
                # FIRST LOOP: Apply all rotations based on trajectory direction
                with (utils.attr_set(store_list) if is_bone_mode else bpy.context.temp_override(**override)):
                    for i, coord in enumerate(sorted_intersection_points):
                        if i == 0:
                            # Set initial rotation keyframe
                            utils.set_keyframe(target, "rotation", current_frame + i * keyframe_duration)
                            continue
                        
                        if i < len(sorted_intersection_points) - 1:
                            # Calculate direction to next point
                            direction_vector = (sorted_intersection_points[i + 1] - coord).normalized()
                        else:
                            # For last point, use direction from previous point
                            direction_vector = (coord - sorted_intersection_points[i - 1]).normalized()
                        
                        # Calculate source vector (direction from previous frame)
                        if i == 1:
                            source_vector = initial_vector
                        else:
                            source_vector = (sorted_intersection_points[i] - sorted_intersection_points[i - 1]).normalized()

                        # Apply rotation to align with trajectory direction
                        utils.apply_ops_rotation(source_vector, direction_vector)
                        utils.set_keyframe(target, "rotation", current_frame + i * keyframe_duration)
                
                ## Restore object to it's initial matrix before position keying
                if is_bone_mode:
                    target.matrix = init_matrix
                else:
                    target.matrix_world = init_matrix
                
                ## End of Rotation keys /

            ## Position keys
            prev_coord = sorted_intersection_points[0]

            for i, coord in enumerate(sorted_intersection_points):
                if i == 0 and props.relative_trajectory:
                    # Keep the initial position as the first keyframe
                    utils.set_keyframe(target, "location", current_frame)
                    continue

                if not props.relative_trajectory:
                    # Jump directly to the trajectory points
                    if is_bone_mode:
                        target.matrix.translation = source_ob.matrix_world.inverted() @ coord
                    else:
                        target.matrix_world.translation = coord
                    # current_position = coord

                else:
                    ## Calculate the position difference and update the current position
                    position_difference = coord - prev_coord
                    current_position += position_difference
                    if is_bone_mode:
                        target.matrix.translation = source_ob.matrix_world.inverted() @ current_position
                    else:
                        target.matrix_world.translation = current_position
                 
                utils.set_keyframe(target, "location", current_frame + i * keyframe_duration)
                
                prev_coord = coord.copy()

            # Update 3D cursor position if auto update cursor is enabled
            if props.auto_update_cursor:
                if is_bone_mode:
                    # to do : fix the get absolute position for bone
                    context.scene.cursor.location = sorted_intersection_points[-1]
                else:
                    context.scene.cursor.location = target.matrix_world.translation # should be same as prevcoord

        elif self.animation_type == 'ROTATION':
            ## Ensure autokey is off (restored later)
            scene.tool_settings.use_keyframe_insert_auto = False
            store_list = []
            override = {}

            ## Init variables
            if is_bone_mode:
                # Bone
                initial_vector = (sorted_intersection_points[0] - (source_ob.matrix_world @ target.matrix).translation).normalized()
                current_world_matrix = (source_ob.matrix_world @ target.matrix).copy()
                # override = {'selected_pose_bones': [target]} # Temp_override bugged with pose bone before 4.4
                store_list = [(pb.bone, 'select', False) for pb in context.selected_pose_bones if pb != target]
                store_list.append((target.bone, 'select', True)) # ensure active is selected
   
            else:
                # Object
                initial_vector = (sorted_intersection_points[0] - target.matrix_world.translation).normalized()
                current_world_matrix = target.matrix_world.copy()
                override = {'selected_objects': [target]}
                # store_list = [(o, (o.select_get, o.select_set), False) for o in context.selected_objects if o != target] #
                # store_list.append((target, (target.select_get, target.select_set), True)) # ensure active is selected

            world_pivot = current_world_matrix.to_translation()
            vector_to_previous_point = None
            
            # with bpy.context.temp_override(**override): # better but bugged with pose-bones before 4.4
            # with utils.attr_set(store_list): # Hassle with object since select is handled through a getter-setter method
            with (utils.attr_set(store_list) if is_bone_mode else bpy.context.temp_override(**override)):
                for i, coord in enumerate(sorted_intersection_points):
                    if i == 0 and props.relative_trajectory:
                        # Keep the initial rotation as the first keyframe
                        utils.set_keyframe(target, "rotation", current_frame)
                        continue

                    # Calculate the vector from the target's initial location to the current point
                    vector_to_current_point = (coord - world_pivot).normalized()

                    ## Define source vector for comparison
                    source_vector = vector_to_previous_point if vector_to_previous_point is not None else initial_vector

                    utils.apply_ops_rotation(source_vector, vector_to_current_point)
                    utils.set_keyframe(target, "rotation", current_frame + i * keyframe_duration)
                    vector_to_previous_point = vector_to_current_point.copy()
                    
                    ## Debug angle viz
                    # deg = f'{math.degrees(source_vector.angle(vector_to_current_point)):.1f}°'
                    # utils.empty_at(source_vector, name=f'{current_frame + i * keyframe_duration}_c_{deg}', show_name=True)
                    # utils.empty_at(vector_to_current_point, name=f'{current_frame + i * keyframe_duration}_nex', show_name=True)

        ### ---- post keyframes

        ## Restore matrix
        if is_bone_mode:
            target.matrix = init_matrix
        else:
            target.matrix_world = init_matrix

        ## Cannot get keys directly some references to keyframes are randomly voided after OPS use.
        # print('Added keys: ', len(added_keys))
        # for k in added_keys:
        #     k.interpolation = props.interpolation_mode
        #     print(k.co.x, 'interpolation -> ', k.interpolation)
        #     k.select_control_point = False

        if source_ob.animation_data and source_ob.animation_data.action:
            for k, values in {k : (fc.data_path, fc.array_index, k.co.x) for fc in source_ob.animation_data.action.fcurves for k in fc.keyframe_points}.items():
                if values in current_keys:
                    continue
                # New key, set interpolation mode
                k.interpolation = props.interpolation_mode

        # Create debug visuals if debug mode is enabled
        if props.debug_mode:
            utils.create_curve_from_points(sorted_intersection_points, ".Animation_Debug_Points")

        scene.tool_settings.use_keyframe_insert_auto = insert_auto_mode

        # Clean up trajectory curve if user doesn't want to keep it
        if not props.keep_trajectory_curve and (curve_obj := context.scene.objects.get(CURVE_NAME)):
            bpy.data.objects.remove(curve_obj, do_unlink=True)

        return {'FINISHED'}

# ## Clear is only available in 4.2... maybe better to remove it entirely
# class OBJECT_OT_clear_active_annotation_frame(bpy.types.Operator):
#     bl_idname = "object.clear_active_annotation_frame"
#     bl_label = "Clear Active Annotation Frame"
#     bl_options = {"REGISTER", "UNDO", "INTERNAL"}

#     @classmethod
#     def poll(cls, context):
#         return active_annotation_frame_poll(context)

#     def execute(self, context):
#         ## Clear method removed in 4.3+
#         context.annotation_data.layers.active.active_frame.clear()
#         return {'FINISHED'}
    
class OBJECT_OT_remove_active_annotation_frame(bpy.types.Operator):
    bl_idname = "object.remove_active_annotation_frame"
    bl_label = "Remove Active Annotation Frame"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return utils.active_annotation_frame_poll(context)

    def execute(self, context):
        utils.remove_active_annotation(context)
        return {'FINISHED'}


classes = [
    OBJECT_OT_simple_animation_operator,
    # OBJECT_OT_clear_active_annotation_frame,
    OBJECT_OT_remove_active_annotation_frame,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
