import bpy
from bpy.types import Operator
from .. import utils
from .. import drawings
from ..constants import CURVE_NAME

class OBJECT_OT_create_curve_from_annotation(Operator):
    bl_idname = "object.create_curve_from_annotation"
    bl_label = "Create Curve From Trajectory"
    bl_description = "Create a curve from the current annotation strokes"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return utils.active_annotation_frame_poll(context)

    def execute(self, context):
        scene = context.scene


        # Get and process trajectory points from annotations
        sorted_intersection_points = drawings.get_processed_trajectory_points(context, 'POSITION')
        
        if isinstance(sorted_intersection_points, str):
            self.report({'ERROR'}, sorted_intersection_points)
            return {'CANCELLED'}
        ## Remove existing trajectory curve if it exists
        # existing_curve = context.scene.objects.get(CURVE_NAME) # from current scene
        ## Curve can exists in another scene. Delete it from data to only keep on active in a single scene
        ## (easier to manage for now, may need improvement in the future to handle mutliple scenees)
        existing_curve = bpy.data.objects.get(CURVE_NAME)
        if existing_curve:
            bpy.data.objects.remove(existing_curve, do_unlink=True)

        # Create a new NURBS curve through the intersection points
        curve_data = bpy.data.curves.new(name=CURVE_NAME, type='CURVE')
        curve_data.dimensions = '3D'
        curve_data.resolution_u = 12
        spline = curve_data.splines.new('POLY') # or NURBS, but need angle
        spline.points.add(len(sorted_intersection_points) - 1)
        spline.use_endpoint_u = True        
        spline.order_u = 2  # Linear for sharp angles

        for i, point in enumerate(sorted_intersection_points):
            # spline.points[i].co = (point[0], point[1], point[2], 1.0)
            spline.points[i].co = (*point, 1.0) # Fourth value is the weight for NURBS/POLY

        curve_object = bpy.data.objects.new(CURVE_NAME, curve_data)
        
        # Set visual settings (how to make point stand out more?)
        # To do : how to make the bevel proportional to the view ? (looks too big on some cases, and small on others)
        curve_data.bevel_depth = 0.005
        # curve_object.show_name = True
        
        context.scene.collection.objects.link(curve_object)

        ## set current annotation opacity to 0.3
        # utils.set_active_annotation_opacity(0.3, context)
        
        ## or simple remove active annotation frame
        utils.remove_active_annotation(context)

        ## Direcly store current target in properties
        props = context.scene.simple_animation_props
        props.previous_active_object = context.view_layer.objects.active.name if context.view_layer.objects.active else ""
        props.previous_mode = context.mode
        props.previous_selected_objects = "|--|".join([obj.name for obj in context.selected_objects])

        ## Directly enter edit mode
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        curve_object.select_set(True)
        context.view_layer.objects.active = curve_object
        bpy.ops.object.mode_set(mode='EDIT')
        
        self.report({'INFO'}, "Trajectory curve created")
        return {'FINISHED'}
        
class OBJECT_OT_remove_trajectory_curve(Operator):
    bl_idname = "object.remove_trajectory_curve"
    bl_label = "Remove Trajectory Curve"
    bl_description = "Remove the trajectory curve"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.scene.objects.get(CURVE_NAME)

    def execute(self, context):
        existing_curve = context.scene.objects.get(CURVE_NAME)
        if existing_curve:
            bpy.data.objects.remove(existing_curve, do_unlink=True)
            self.report({'INFO'}, "Trajectory curve removed")
            
            ## Reset curve target properties
            props = context.scene.simple_animation_props
            props.previous_active_object =  ""
            props.previous_mode = ""
            props.previous_selected_objects =  ""
        
        ## Reset annotation opacity (if annotation is active)
        # utils.set_active_annotation_opacity(1.0, context)
        return {'FINISHED'}

class OBJECT_OT_edit_trajectory_curve(Operator):
    bl_idname = "object.edit_trajectory_curve"
    bl_label = "Edit Trajectory Curve"
    bl_description = "Switch object to curve and enter edit mode\
        \nPrevious selection and mode are restored after clicking 'Finish Editing' button"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.scene.objects.get(CURVE_NAME)

    def execute(self, context):
        props = context.scene.simple_animation_props
        curve_object = context.scene.objects.get(CURVE_NAME)
        
        ## Store selection and mode (only if active object is not the curve)
        if context.object and context.object != curve_object:
            props.previous_active_object = context.view_layer.objects.active.name if context.view_layer.objects.active else ""
            props.previous_mode = context.mode
            props.previous_selected_objects = "|--|".join([obj.name for obj in context.selected_objects])
        
        ## Select curve and go in edit mode
        if curve_object:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            curve_object.select_set(True)
            context.view_layer.objects.active = curve_object
            bpy.ops.object.mode_set(mode='EDIT')

        return {'FINISHED'}

def restore_previous_selection(context):
    """Restore previous selection and mode
    Return restored active object if any
    """

    props = context.scene.simple_animation_props

    # Exit edit mode
    if context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    # Restore previous selection
    bpy.ops.object.select_all(action='DESELECT')

    # Split the comma-separated list of object names
    prev_selected = props.previous_selected_objects.split('|--|') if props.previous_selected_objects else []
    for obj_name in prev_selected:
        if obj_name.strip():
            if obj := context.scene.objects.get(obj_name):
                obj.select_set(True)
    
    restored_active = None
    # Restore active object
    if props.previous_active_object:
        if active_obj := context.scene.objects.get(props.previous_active_object):
            context.view_layer.objects.active = active_obj
            restored_active = active_obj

    # Restore previous mode if it wasn't OBJECT
    if props.previous_mode and props.previous_mode != 'OBJECT':
        try:
            bpy.ops.object.mode_set(mode=props.previous_mode)
        except:
            # Handle case where the mode is not valid for the current selection
            # print('Curve Finish edit: Could not restore mode')
            pass
    return restored_active

class OBJECT_OT_return_from_curve_edit(Operator):
    bl_idname = "object.return_from_curve_edit"
    bl_label = "Return From Curve Edit"
    bl_description = "Return to previous selection after editing the curve"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.object and context.mode == 'EDIT_CURVE' and context.object.name == CURVE_NAME

    def execute(self, context):
        restore_previous_selection(context)
        return {'FINISHED'}

def register():
    bpy.utils.register_class(OBJECT_OT_create_curve_from_annotation)
    bpy.utils.register_class(OBJECT_OT_remove_trajectory_curve)
    bpy.utils.register_class(OBJECT_OT_edit_trajectory_curve)
    bpy.utils.register_class(OBJECT_OT_return_from_curve_edit)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_return_from_curve_edit)
    bpy.utils.unregister_class(OBJECT_OT_edit_trajectory_curve)
    bpy.utils.unregister_class(OBJECT_OT_remove_trajectory_curve)
    bpy.utils.unregister_class(OBJECT_OT_create_curve_from_annotation)