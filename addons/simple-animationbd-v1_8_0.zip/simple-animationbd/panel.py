import bpy
from .constants import CURVE_NAME
from . import utils

def show_operator_shortcut(layout, idname='POSITION', animation_type=''):
    if not (keyconfig := bpy.context.window_manager.keyconfigs.addon):
        return
    if not (keymap := keyconfig.keymaps.get('3D View')):
        return
    for kmi in keymap.keymap_items:
        if kmi.idname == idname:
            if animation_type and hasattr(kmi.properties, 'animation_type')\
                and kmi.properties.animation_type != animation_type:
                continue
            shortcut_str = " + ".join(kmi.to_string().split())
            layout.label(text=f"Shortcut: {shortcut_str}", icon='KEYTYPE_KEYFRAME_VEC')
            return

class VIEW3D_PT_simple_animation_ui(bpy.types.Panel):
    bl_label = "Simple Animation Graph"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Animation"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        col = layout.column(align=False)
        col.separator()
        col.label(text="Animation:")
        col = layout.column(align=False)
        col.scale_y = 1.3

        prefs = utils.get_prefs()
        anim_position_text = 'Animate Position'
        anim_rotation_text = 'Animate Rotation'
        if utils.curve_exists_poll(context):
            anim_position_text = 'Animate Position From Curve'
            anim_rotation_text = 'Animate Rotation From Curve'

        col.operator("object.simple_animation_operator", 
            text=anim_position_text, icon='TRACKING').animation_type = 'POSITION'

        # Show shortcut dynamically
        if prefs.use_shortcut_ui_display:
            show_operator_shortcut(col, idname='object.simple_animation_operator', animation_type='POSITION')

        col.operator("object.simple_animation_operator", 
            text=anim_rotation_text, icon='DRIVER_ROTATIONAL_DIFFERENCE').animation_type = 'ROTATION'
        
        if prefs.use_shortcut_ui_display:
            show_operator_shortcut(col, idname='object.simple_animation_operator', animation_type='ROTATION')

class VIEW3D_PT_simple_animation_trajectory(bpy.types.Panel):
    bl_label = "Edit trajectory"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Animation"
    bl_parent_id = "VIEW3D_PT_simple_animation_ui"
    bl_order = 1
    # bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        props = scene.simple_animation_props
        layout.use_property_split = True
        layout.use_property_decorate = False

        col = layout.column(align=False)
        
        ## label Hoisting: content of title_row is defined further in condition block
        title_row = col.row(align=False)
        
        if curve := context.scene.objects.get(CURVE_NAME):
            row = col.row(align=False)
            if context.object == curve and context.mode == 'EDIT_CURVE':
                # title_row.label(text="Editing trajectory Curve")
                row.operator("object.return_from_curve_edit", text="Finish Editing", icon='CHECKMARK')
            else:
                # title_row.label(text="Using trajectory Curve")
                row.operator("object.edit_trajectory_curve", text="Edit Curve", icon='EDITMODE_HLT')
            
            row.operator("object.remove_trajectory_curve", text="Remove Curve", icon='X')
            title_row.prop(props, "keep_trajectory_curve", text="Keep curve")
        else:
            # title_row.label(text="Add trajectory Curve")
            col.operator("object.create_curve_from_annotation", text="Edit trajectory as curve", icon='CURVE_DATA')

class VIEW3D_PT_simple_animation_settings(bpy.types.Panel):
    bl_label = "Settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Animation"
    bl_parent_id = "VIEW3D_PT_simple_animation_ui"
    bl_order = 2
    # bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        props = scene.simple_animation_props
        layout.use_property_split = True
        layout.use_property_decorate = False

        col = layout.column(align=False)
        col.prop(props, "timing")
        if props.timing == 'by_step':
            col.prop(props, "keyframe_step")
        elif props.timing == 'by_duration':
            col.prop(props, "frames_duration")

        col.prop(props, "interpolation_mode", text="Interpolation")

        # if props.interpolation_mode == 'BEZIER':
        #     hint_col = col.column(align=True)
        #     hint_col.label(text="In Bezier mode, try to separate keyframes", icon='ERROR')
        #     hint_col.label(text="by 3 or 4 frames at least to avoid jumps", icon='BLANK1')

class VIEW3D_PT_simple_animation_advanced(bpy.types.Panel):
    bl_label = "Advanced Settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Animation"
    bl_parent_id = "VIEW3D_PT_simple_animation_settings"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        props = scene.simple_animation_props
        layout.use_property_split = True
        layout.use_property_decorate = False

        col = layout.column(align=False)
        col.prop(props, "auto_update_cursor", text="Update 3D Cursor")

        col.prop(props, "reverse_trajectory")

        col.prop(props, "relative_trajectory")

        col.prop(props, "orient_to_trajectory")

        ## Comment debug mode when shipping
        # col.separator()
        # col.prop(props, "debug_mode")

        col.label(text="Use Axis:")
        row = col.row(align=True)

        row.use_property_split = False
        row.prop(props, "use_x", toggle=True, text="X")
        row.prop(props, "use_y", toggle=True, text="Y")
        row.prop(props, "use_z", toggle=True, text="Z")

        # Show the Preview Axis button
        row = col.row()
        row.enabled = not props.preview_active
        row.operator("object.preview_axis_operator", text=props.preview_label or "Preview Axis")

class VIEW3D_PT_simple_animation_tools(bpy.types.Panel):
    bl_label = "Tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Animation"
    bl_parent_id = "VIEW3D_PT_simple_animation_ui"
    bl_order = 3
    # bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        col = layout.column(align=False)
        col.operator("view3d.snap_cursor_to_selected", text="Cursor to Selected", icon='CURSOR')

        row = col.row(align=True)
        row.operator("object.remove_active_annotation_frame", text="Remove Annotation Frame", icon='X')


### --- info notes --- ###

def show_message_box(message = "", title = "Message Box", icon = 'INFO'):
    '''Show message box with element passed as string or list
    if message if a list of lists:
        if sublist have 2 element:
            considered a label [text, icon]
        if sublist have 3 element:
            considered as an operator [ops_id_name, text, icon]
        if sublist have 4 element:
            considered as a property [object, propname, text, icon]
    '''

    def draw(self, context):
        layout = self.layout
        for l in message:
            if isinstance(l, str):
                layout.label(text=l)
            elif len(l) == 2: # label with icon
                layout.label(text=l[0], icon=l[1])
            elif len(l) == 3: # ops
                layout.operator_context = "INVOKE_DEFAULT"
                layout.operator(l[0], text=l[1], icon=l[2], emboss=False) # <- highligh the entry
            elif len(l) == 4: # prop
                row = layout.row(align=True)
                row.label(text=l[2], icon=l[3])
                row.prop(l[0], l[1], text='') 
    
    if isinstance(message, str):
        message = [message]
    bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)


## Unused for now
class SIMPLEANIM_OT_info_note(bpy.types.Operator):
    bl_idname = "simpleanim.info_note"
    bl_label = "Info Note"
    bl_description = "Info Note"
    bl_options = {"REGISTER", "INTERNAL"}

    text : bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
    title : bpy.props.StringProperty(default='Help', options={'SKIP_SAVE'})
    icon : bpy.props.StringProperty(default='INFO', options={'SKIP_SAVE'})

    @classmethod
    def description(self, context, properties):
        return properties.text

    def execute(self, context):
        ## Split text in list of lines
        lines = self.text.split('\n')
        show_message_box(message=lines, title=self.title, icon=self.icon)
        return {"FINISHED"}


classes = (
    SIMPLEANIM_OT_info_note,
    VIEW3D_PT_simple_animation_ui,
    VIEW3D_PT_simple_animation_trajectory,
    VIEW3D_PT_simple_animation_settings,
    VIEW3D_PT_simple_animation_advanced,
    VIEW3D_PT_simple_animation_tools,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)