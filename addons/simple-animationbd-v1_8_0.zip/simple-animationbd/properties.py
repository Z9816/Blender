import bpy

class SimpleAnimationProperties(bpy.types.PropertyGroup):

    debug_mode: bpy.props.BoolProperty(name="Debug mode", default=False)

    # animate_type: bpy.props.EnumProperty(
    #     name="Animation Type",
    #     description="Choose whether to animate position or rotation",
    #     items=[
    #         ('POSITION', "Position", "Animate object position"),
    #         ('ROTATION', "Rotation", "Animate object rotation")
    #         #, ('SCALE', "Scale", "Animate object scale"),
    #     ],
    #     default='POSITION'
    # )

    timing: bpy.props.EnumProperty(
        name="Timing",
        description="How to time the animation",
        items=[
            ('by_step', "By step", "length of each keyframe"),
            ('by_duration', "By total duration", "Duration of whole animation")
        ],
        default='by_step'
    )

    keyframe_step: bpy.props.IntProperty(
        name="Keyframe Step",
        description="Number of frames between keyframes",
        default=2,
        min=1
    )

    frames_duration: bpy.props.IntProperty(
        name="Frames Duration",
        description="Number of frames for the whole animation",
        default=48,
        min=1
    )

    interpolation_mode: bpy.props.EnumProperty(
        name="Interpolation Mode",
        description="Keyframe interpolation mode",
        items=[
            ('CONSTANT', "Constant (stop-mo style)", "No interpolation between keyframes"),
            ('BEZIER', "Bezier", "Smooth interpolation (default)"),
            ('LINEAR', "Linear", "Linear interpolation")
        ],
        default='LINEAR'
    )
    # track_axis: bpy.props.EnumProperty(
    #     name="Front",
    #     description="Which axis will point to trajectory you draw",
    #     items=[
    #         ('AUTO', "Auto", "Auto axis for the target"),
    #         ('TRACK_X', "+X Axis", "Make the X axis point to the target"),
    #         ('TRACK_Y', "+Y Axis", "Usually the "),
    #         ('TRACK_Z', "+Z Axis", "Make the Z axis point to the target"),
    #         ('TRACK_NEGATIVE_X', "-X Axis", "Make the -X axis point to the target"),
    #         ('TRACK_NEGATIVE_Y', "-Y Axis", "Make the -Y axis point to the target"),
    #         ('TRACK_NEGATIVE_Z', "-Z Axis", "Make the -Z axis point to the target")
    #     ],
    #     default='AUTO'
    # )

    # up_axis: bpy.props.EnumProperty(
    #     name="Up",
    #     description="which axis will be perpendicular to the trajectory you draw ",
    #     items=[
    #         ('AUTO', "Auto", "Auto axis for the top"),
    #         ('UP_X', "X Axis", "Make the X axis the top"),
    #         ('UP_Y', "Y Axis", "Make the Y axis the top"),
    #         ('UP_Z', "Z Axis", "Make the Z axis the top")
    #     ],
    #     default='AUTO'
    # )
    relative_trajectory: bpy.props.BoolProperty(
        name="Relative Trajectory",
        description="Keep the offset between the curve and the object",
        default=True
    )
    use_x: bpy.props.BoolProperty(name="Use X", default=True)
    
    use_y: bpy.props.BoolProperty(name="Use Y", default=True)
    
    use_z: bpy.props.BoolProperty(name="Use Z", default=True)
    
    show_gizmos: bpy.props.BoolProperty(name="Show Gizmos", default=False)
    
    preview_active: bpy.props.BoolProperty(default=False)
    
    preview_label: bpy.props.StringProperty(default="Preview Axis")

    auto_update_cursor: bpy.props.BoolProperty(name="Auto Update 3d Cursor", default=True)
    
    reverse_trajectory: bpy.props.BoolProperty(name="Reverse Trajectory", default=False)

    orient_to_trajectory: bpy.props.BoolProperty(
        name="Orient to Path",
        description="When using 'Animate Position', animate rotation as well to orient object/bone along trajectory",
        default=False
    )

    show_advanced: bpy.props.BoolProperty(name="Show Advanced Settings", default=False)

    ## -- Curve properties
    keep_trajectory_curve: bpy.props.BoolProperty(
        name="Keep Curve",
        description="Keep the trajectory curve after animation instead of deleting it",
        default=False
    )

    ## Storage when switching to editing mode
    previous_active_object: bpy.props.StringProperty(default="")
    
    previous_mode: bpy.props.StringProperty(default="OBJECT")
    
    previous_selected_objects: bpy.props.StringProperty(default="")


def register():
    bpy.utils.register_class(SimpleAnimationProperties)
    bpy.types.Scene.simple_animation_props = bpy.props.PointerProperty(type=SimpleAnimationProperties)

def unregister():
    bpy.utils.unregister_class(SimpleAnimationProperties)
    del bpy.types.Scene.simple_animation_props
