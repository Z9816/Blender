import bpy
from mathutils.geometry import intersect_line_line, intersect_line_plane
from mathutils import Vector
from . import utils
from .constants import CURVE_NAME

def calculate_intersection(p1, p2, p3, p4, threshold=1):
    """
    Calculate intersection between two line segments in 3D space.
    Returns None if segments don't intersect or closest point if they're close enough.

    Parameters:
        p1, p2: First line segment endpoints
        p3, p4: Second line segment endpoints
        threshold: Distance threshold for considering points as intersecting
    """

    intersection = intersect_line_line(p1, p2, p3, p4)

    if not intersection:
        # Lines don't intersect
        return None

    point1, point2 = intersection

    segment1_length = (p2 - p1).length
    segment2_length = (p4 - p3).length

    if (point1 - point2).length > threshold:
        # Check if points are close enough to be considered intersecting
        return None

    ### Limit to segment (Check if intersection points lie within the segments)
    ## -- end points distance
    ## / Using distance to endpoints (more undertandable but potentially slighlty-slower)

    if (((point1 - p1).length < segment1_length and (point1 - p2).length < segment1_length) and
        ((point2 - p3).length < segment2_length and (point2 - p4).length < segment2_length)):

        ## return point on main trajectory (trajectory segment should be passed as first pair !)
        return point1
        ## Alternatively, return the average of the closest points
        # return (point1 + point2) * 0.5
    return None

def get_current_gp_object(get_annotation=False):

    gpencil = None
    source_type = "annotation" if get_annotation else "Grease Pencil"
    if get_annotation:
        ## Get active annotation GP data in current scene
        gpencil = bpy.context.annotation_data
    else:
        ## Get active object if active and of the right type
        gp_type = 'GREASEPENCIL' if bpy.app.version >= (4, 3, 0) else 'GPENCIL'
        if bpy.context.object and bpy.context.object.type == gp_type:
            gpencil = bpy.context.object
        else:
            raise RuntimeError("No active Grease Pencil object found.")

    if not gpencil:
        raise RuntimeError(f"No {source_type} data found.")

    return gpencil, get_annotation

def get_strokes_in_gp(gpencil):
    if not gpencil:
        raise RuntimeError("Invalid Grease Pencil data.")

    if bpy.app.version >= (4, 3, 0):
        if isinstance(gpencil, bpy.types.GreasePencil):
            # under gpv3 annotation type is GreasePencil
            if gpencil.layers.active_index < 0:
                raise RuntimeError("No drawn lines found.")
            layer = gpencil.layers[gpencil.layers.active_index]
        else:
            # gpv3 layers do not have an active_index anymore
            layer = gpencil.layers.active

    else:
        if not gpencil.layers.active:
            raise RuntimeError("No active layer in Grease Pencil data.")
        layer = gpencil.layers.active

    if not layer or not layer.active_frame:
        raise RuntimeError("No drawn lines found.")

    # Print information about the current layer and frame

    frame = layer.active_frame

    ## Strokes to list of points coordinates
    strokes = []
    for stroke in frame.strokes:
        stroke_points = [p.co for p in stroke.points]
        strokes.append(stroke_points)

    return strokes

def get_trajectory(gpencil, is_annotation, simplify=1):

    strokes = get_strokes_in_gp(gpencil.data) if not is_annotation else get_strokes_in_gp(gpencil)
    if not strokes:
        raise RuntimeError("No lines found on current frame. Please draw a trajectory line.")

    max_length = 0
    trajectory_points = None
    traj_stroke_index = None

    # Find the longest line in the annotations to be considered as the main trajectory
    for stroke_index, pt_coords in enumerate(strokes):
        ## pt_coords is a lsit of coodinates
        length = sum((pt_coords[i] - pt_coords[i - 1]).length for i in range(1, len(pt_coords)))
        if length > max_length:
            longest_line = list(pt_coords)
            max_length = length
            traj_stroke_index = stroke_index

    if max_length < 0.001: 
        # Check if trajectory is too short (or there at all)
        raise RuntimeError("No trajectory line (or trajectory is too short)")
    # if not longest_line:
    #     raise RuntimeError("Please draw a trajectory line.")


    # Ensure correct order of strokes along the trajectory
    intersection_points = []
    processed_strokes_indexes = set()

    #convert the points in the longest line from point.co to point 
    trajectory_points = [coord for coord in longest_line] # same as copy/deepcopy
    trajectory_points = simplify_points(trajectory_points, simplify)

    # Iterate over trajectory segments in the correct order
    for i in range(1, len(trajectory_points)):
        curr_segment_start = trajectory_points[i - 1]
        curr_segment_end = trajectory_points[i]
        # print(f"current segment : [{i - 1}-{i}]") #Dbg

        for j, coords in enumerate(strokes):
            if j in processed_strokes_indexes or j == traj_stroke_index:
                continue  # Skip already processed strokes or the trajectory itself

            if len(coords) < 2:
                continue  # Skip strokes with less than 2 points

            intersection = None
            for k in range(1, len(coords)):
                pair_a = coords[k - 1]
                pair_b = coords[k]
                intersection = calculate_intersection(curr_segment_start, curr_segment_end, pair_a, pair_b)
                if intersection:
                    break

            ## first fallback: on simple method
            if not intersection:
                point_a = coords[0]
                point_b = coords[-1]
                # Calculate intersection ensuring the strokes are processed in the correct order
                intersection = calculate_intersection(curr_segment_start, curr_segment_end, point_a, point_b)

            ## second fallback: use a threshold-based approximation 
            ## (/!\ Should be done in another loop other fail the whole thing !)
            # if not intersection:
            #     midpoint_trajectory = (curr_segment_start + curr_segment_end) / 2
            #     midpoint_stroke = (point_a + point_b) / 2
            #     if (midpoint_trajectory - midpoint_stroke).length <= threshold_distance:
            #         print(f"stroke {j} added by proximity {(midpoint_trajectory - midpoint_stroke).length} <= {threshold_distance}")
            #         intersection = midpoint_stroke
            #     else:
            #         print(f"stroke {j} not intersecting and not close enough")
            # else:
            #     print(f"stroke {j} intersecting !")

            if intersection:
                intersection_points.append(intersection)
                processed_strokes_indexes.add(j)
                # print(j) #Dbgdddddd
                break

    if not intersection_points or len(intersection_points) < 2:
        raise RuntimeError("Not enough intersections detected. Please draw at least 2 intersections on the trajectory without moving the view.")

    # pp(intersection_points)
    # create_debug_curve(intersection_points, collection_name='raw_points')
    
    ## Prepend the first point of the trajectory stroke
    # intersection_points.insert(0, trajectory_points[0])

    return intersection_points

# Unused yet
def subdivide_points(points, multiplier=1):
    """
    Subdivide a list of points by adding interpolated points between each pair.

    Parameters:
        points (list of Vector): Points to subdivide.
        multiplier (int): Number of additional points to add between each pair (0 = no change).

    Returns:
        list of Vector: Subdivided points.
    """
    if multiplier <= 0:
        return points[:]  # Return original points if multiplier is 0 or less

    subdivided_points = [points[0]]  # Always keep the first point
    for i in range(1, len(points)):
        start_point = points[i - 1]
        end_point = points[i]
        step_fraction = 1 / (multiplier + 1)

        # Add interpolated points
        for step in range(1, multiplier + 1):
            factor = step * step_fraction
            subdivided_points.append(start_point.lerp(end_point, factor))

        subdivided_points.append(end_point)

    return subdivided_points


def simplify_points(points, multiplier=1):
    """
    Simplify a list of points by skipping points based on the multiplier.

    Parameters:
        points (list of Vector): Points to simplify.
        multiplier (int): Number of steps to skip (0 = no change).

    Returns:
        list of Vector: Simplified points.
    """
    if multiplier <= 0:
        return points[:]  # Return original points if multiplier is 0 or less

    simplified_points = [points[0]]  # Always keep the first point
    for i in range(1, len(points) - 1):
        if i % (multiplier + 1) == 0:
            simplified_points.append(points[i])

    simplified_points.append(points[-1])  # Always keep the last point
    return simplified_points

def get_curve_trajectory_points(curve_obj, evaluated=False, context=None):
    """
    Get trajectory points from passed curve object
    
    Returns:
        List of points from the curve or error string
    """
    
    context = context or bpy.context
    
    ## TODO: work on evaluated curve
    # if evaluated:
    #     evaluated_curve = curve_obj.evaluated_get(context.evaluated_depsgraph_get())
    #     if evaluated_curve:
    #         final_curve = evaluated_curve        
    #     else:
    #         # return "Failed to evaluate path curve."
    #         # Fallback to original curve if evaluation fails
    #         final_curve = curve_obj
    # else:
    #     final_curve = curve_obj
    
    final_curve = curve_obj

    if not final_curve.data.splines or len(final_curve.data.splines) == 0:
        return "Path curve has no splines."
        
    # Get the points from the first spline in curve object
    spline = final_curve.data.splines[0]
    points = []

    # Handle both NURBS and Bezier curve types
    if spline.type in ('NURBS', 'POLY'):
        # Convert Vector4 prop to 3D vector (discard 4th value, NURBS/POLY point weight)
        points = [final_curve.matrix_world @ Vector(point.co[:3]) for point in spline.points]
    elif spline.type == 'BEZIER':
        points = [final_curve.matrix_world @ point.co for point in spline.bezier_points]

    if len(points) < 2:
        return "Path curve has too few points."
        
    return points

def process_trajectory_points(context, points, animation_type, use_x, use_y, use_z, debug_mode=False, reverse=False):
    """
    Process trajectory points for animation, including axis constraints
    
    Parameters:
        context: Blender context
        points: List of trajectory points
        animation_type (str): 'POSITION' or 'ROTATION'
        use_x, use_y, use_z (bool): flags for axis constraints
        debug_mode: Whether to create debug visualization
        reverse: Whether to reverse the trajectory
        
    Returns:
        List of processed points or error string if there's an issue
    """

    if len(points) < 2:
        return "Draw at least 2 intersections on the trajectory."
        
    # Make a copy of the points to avoid modifying the original
    sorted_intersection_points = [p.copy() for p in points]
    
    if reverse:
        sorted_intersection_points.reverse()

    if debug_mode:
        # Purge before debug
        for obj in reversed(bpy.data.objects):
            if obj.type == 'EMPTY' and obj.name.startswith(("L_", "W_", "F_")):
                # Remove existing empties with names "L_##" and "W_##"
                bpy.data.objects.remove(obj, do_unlink=True)
    
        # Show initial position
        utils.create_emptys_from_list(sorted_intersection_points, prefix="W_", show_name=True)

    # If some axis are constrained, reproject points on plane
    axis_to_use = [use_x, use_y, use_z]
    if not all(axis_to_use):
        # Get the active object or bone
        obj = context.active_object
        if not obj:
            return "No active object selected."
            
        is_bone_mode = obj.type == 'ARMATURE' and context.mode == 'POSE'
        
        if is_bone_mode:
            bone = context.active_pose_bone
            if not bone:
                return "No active bone in Pose Mode."
            target = bone
        else:
            target = obj
            
        # List locked axis indices
        if animation_type == 'POSITION':
            axis_locked_indices = [i for i, axis_bool in enumerate(axis_to_use) if not axis_bool]  # location
        else:
            axis_locked_indices = [i for i, axis_bool in enumerate(axis_to_use) if axis_bool]  # inverse for rotation
            # On rotation, locking 2 axis is equivalent to using only the third one
            if len(axis_locked_indices) == 2:
                # ex: [0, 1] -> [2]
                axis_locked_indices = [i for i in range(3) if i not in axis_locked_indices]
            
        axis_locked_indices.reverse()  # reverse needed?

        # Constrain on locked axis
        loc, axis_directions = utils.get_position_and_axis_direction(target)
        
        # Debug constraint plane
        if debug_mode:
            utils.empty_at(loc, "loc", type="ARROWS", size=0.1, show_name=True)
            utils.empty_at(loc + axis_directions[0], name="X", type="SPHERE", show_name=True)
            utils.empty_at(loc + axis_directions[1], name="Y", type="SPHERE", show_name=True)
            utils.empty_at(loc + axis_directions[2], name="Z", type="SPHERE", show_name=True)
        
        # Apply axis constraint on points
        for lock_index in axis_locked_indices:
            direction = axis_directions[lock_index]
            sorted_intersection_points = [intersect_line_plane(p, p+direction, loc, direction) for p in sorted_intersection_points]

    return sorted_intersection_points

def get_processed_trajectory_points(context, animation_type):
    """
    Get trajectory points either from annotations or curve
    
    Parameters:
        context: Blender context
        animation_type: 'POSITION' or 'ROTATION'
        
    Returns:
        List of processed points or error string if there's an issue
    """
    props = context.scene.simple_animation_props
    
    # First try to get points from trajectory curve if it exists
    
    if curve_obj := context.scene.objects.get(CURVE_NAME):
        if curve_obj.type != 'CURVE':
            return f'Found path object is not a curve type: "{CURVE_NAME}"'
        
        points = get_curve_trajectory_points(curve_obj, context=context)
        if isinstance(points, str):
            # Return the error (Should it fall back to annotations instead ?)
            return points

        return process_trajectory_points(
            context,
            points,
            animation_type,
            props.use_x,
            props.use_y,
            props.use_z,
            props.debug_mode,
            props.reverse_trajectory
        )
    
    # Get points from annotations
    try:
        gpencil, is_annotation = get_current_gp_object(get_annotation=True)
        points = get_trajectory(gpencil, is_annotation)
        
        return process_trajectory_points(
            context,
            points,
            animation_type,
            props.use_x,
            props.use_y,
            props.use_z,
            props.debug_mode,
            props.reverse_trajectory
        )
    except RuntimeError as e:
        return str(e)