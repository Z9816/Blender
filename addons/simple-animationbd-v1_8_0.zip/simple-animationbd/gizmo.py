import bpy
import math

from math import radians
from mathutils import Vector, Matrix

class OBJECT_GGT_simple_animation_gizmo(bpy.types.GizmoGroup):
    bl_label = "Simple Animation Gizmo"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'3D', 'PERSISTENT'}

    def setup(self, context):
        # Create the gizmos (persistent)

        ## Translations
        self.gizmo_pos_x = self.gizmos.new("GIZMO_GT_arrow_3d") #GIZMO_GT_arrow_3d")
        self.gizmo_pos_x.color = (1, 0, 0)
        self.gizmo_pos_x.alpha = 0.5
        self.gizmo_pos_x.hide_select = True

        self.gizmo_pos_y = self.gizmos.new("GIZMO_GT_arrow_3d")#
        self.gizmo_pos_y.color = (0, 1, 0)
        self.gizmo_pos_y.alpha = 0.5
        self.gizmo_pos_y.hide_select = True

        self.gizmo_pos_z = self.gizmos.new("GIZMO_GT_arrow_3d")#
        self.gizmo_pos_z.color = (0, 0, 1)
        self.gizmo_pos_z.alpha = 0.5
        self.gizmo_pos_z.hide_select = True

        ## Rotations
        self.gizmo_rot_x = self.gizmos.new("GIZMO_GT_dial_3d") #GIZMO_GT_arrow_3d")
        self.gizmo_rot_x.color = (1, 0, 0)
        self.gizmo_rot_x.alpha = 0.5
        self.gizmo_rot_x.hide_select = True

        self.gizmo_rot_y = self.gizmos.new("GIZMO_GT_dial_3d")#
        self.gizmo_rot_y.color = (0, 1, 0)
        self.gizmo_rot_y.alpha = 0.5
        self.gizmo_rot_y.hide_select = True

        self.gizmo_rot_z = self.gizmos.new("GIZMO_GT_dial_3d")#
        self.gizmo_rot_z.color = (0, 0, 1)
        self.gizmo_rot_z.alpha = 0.5
        self.gizmo_rot_z.hide_select = True

    def draw_prepare(self, context):
        obj = context.object
        props = context.scene.simple_animation_props
        if not obj or not props.show_gizmos:
            ## avoid further processing if gizmos are hidden
            self.gizmo_rot_x.hide = True
            self.gizmo_rot_y.hide = True
            self.gizmo_rot_z.hide = True
            self.gizmo_pos_x.hide = True
            self.gizmo_pos_y.hide = True
            self.gizmo_pos_z.hide = True
            return

        pose_bone = None
        if obj.type == 'ARMATURE' and context.mode == 'POSE':
            pose_bone = context.active_pose_bone

        if pose_bone:
            armature = pose_bone.id_data
            matrix = armature.matrix_world @ pose_bone.matrix
        else:
            matrix = obj.matrix_world

        # Animate gizmo with sinusoidal motion
        time_elapsed = 2.0 - context.window_manager.simple_animation_preview_countdown

        # Adjust amplitude and speed
        offset = math.sin(time_elapsed * math.pi * 1.5) * 0.1

        # Gizmos for location
        self.gizmo_pos_x.matrix_basis = matrix @ Matrix.Rotation(radians(90), 4, 'Y') @ Matrix.Translation(Vector((0, 0, offset)))
        self.gizmo_pos_y.matrix_basis = matrix @ Matrix.Rotation(radians(-90), 4, 'X') @ Matrix.Translation(Vector((0, 0, offset)))
        self.gizmo_pos_z.matrix_basis = matrix @ Matrix.Translation(Vector((0, 0, offset)))

        # Gizmos for rotation
        self.gizmo_rot_x.matrix_basis = matrix @ Matrix.Rotation(radians(90), 4, 'Y')
        self.gizmo_rot_y.matrix_basis = matrix @ Matrix.Rotation(radians(90), 4, 'X')
        self.gizmo_rot_z.matrix_basis = matrix @ Matrix.Rotation(radians(90), 4, 'Z')

        self.gizmo_rot_x.hide = not props.use_x
        self.gizmo_rot_y.hide = not props.use_y
        self.gizmo_rot_z.hide = not props.use_z
        self.gizmo_pos_x.hide = not props.use_x
        self.gizmo_pos_y.hide = not props.use_y
        self.gizmo_pos_z.hide = not props.use_z

# Register and Unregister Functions
def register():
    bpy.utils.register_class(OBJECT_GGT_simple_animation_gizmo)

def unregister():
    bpy.utils.unregister_class(OBJECT_GGT_simple_animation_gizmo)