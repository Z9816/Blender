import bpy
from bpy.types import AddonPreferences
from bpy.props import BoolProperty, StringProperty

addon_keymaps = []

def register_shortcuts():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon

    if kc:
        # Access preferences
        prefs = bpy.context.preferences.addons[__package__].preferences

        ## Position
        if prefs.enable_position_shortcut:
            km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")
            kmi = km.keymap_items.new(
                'object.simple_animation_operator', 
                prefs.key_shortcut_position, 
                'PRESS', 
                ctrl=prefs.use_ctrl_position, 
                shift=prefs.use_shift_position, 
                alt=prefs.use_alt_position
            )
            kmi.properties.animation_type = "POSITION"        
            addon_keymaps.append((km, kmi))

        ## Rotation
        if prefs.enable_rotation_shortcut:
            km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")
            kmi = km.keymap_items.new(
                'object.simple_animation_operator', 
                prefs.key_shortcut_rotation, 
                'PRESS', 
                ctrl=prefs.use_ctrl_rotation, 
                shift=prefs.use_shift_rotation, 
                alt=prefs.use_alt_rotation
            )
            kmi.properties.animation_type = "ROTATION"        
            addon_keymaps.append((km, kmi))

def unregister_shortcuts():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

def update_shortcuts(self, context):
    unregister_shortcuts()
    register_shortcuts()

class SimpleAnimationPreferences(AddonPreferences):
    bl_idname = __package__

    # Position shortcut properties
    enable_position_shortcut: BoolProperty(
        name = "Enable Position Shortcut",
        description = "Enable shortcut for position animation",
        default = True,
        update = update_shortcuts
    )
    
    key_shortcut_position: StringProperty(
        name = "Position Key",
        description = "Key for position animation",
        default = "A",
        update = update_shortcuts
    )

    use_shift_position: BoolProperty(
        name = "Shift",
        description = "Use Shift modifier for position",
        default = True,
        update = update_shortcuts
    )

    use_alt_position: BoolProperty(
        name = "Alt",
        description = "Use Alt modifier for position",
        default = True,
        update = update_shortcuts
    )

    use_ctrl_position: BoolProperty(
        name = "Ctrl",
        description = "Use Ctrl modifier for position",
        default = False,
        update = update_shortcuts
    )

    # Rotation shortcut properties
    enable_rotation_shortcut: BoolProperty(
        name = "Enable Rotation Shortcut",
        description = "Enable shortcut for rotation animation",
        default = True,
        update = update_shortcuts
    )
    
    key_shortcut_rotation: StringProperty(
        name = "Rotation Key",
        description = "Key for rotation animation",
        default = "R",
        update = update_shortcuts
    )

    use_shift_rotation: BoolProperty(
        name = "Shift",
        description = "Use Shift modifier for rotation",
        default = True,
        update = update_shortcuts
    )

    use_alt_rotation: BoolProperty(
        name = "Alt",
        description = "Use Alt modifier for rotation",
        default = True,
        update = update_shortcuts
    )

    use_ctrl_rotation: BoolProperty(
        name = "Ctrl",
        description = "Use Ctrl modifier for rotation",
        default = False,
        update = update_shortcuts
    )

    ## Display settings
    # use_hints: BoolProperty(
    #     name = "Show Help And Hints",
    #     description = "Show text hints in interface",
    #     default = True,
    # )

    use_shortcut_ui_display: BoolProperty(
        name = "Show Key Shortcuts",
        description = "Show shortcut in interface",
        default = False,
    )

    def draw(self, context):
        layout = self.layout

        layout.label(text="Keymaps:")
        ## Position shortcut
        box = layout.box()
        col = box.column()
        row = col.row()
        row.prop(self, "enable_position_shortcut", text="Position Shortcut")
        
        if self.enable_position_shortcut:
            row = col.row(align=True)
            row.prop(self, "key_shortcut_position", text="")
            row.separator()
            self.draw_modifier_buttons(row, "use_ctrl_position", "use_alt_position", "use_shift_position")
        
        ## Rotation shortcut
        box = layout.box()
        col = box.column()
        row = col.row()
        row.prop(self, "enable_rotation_shortcut", text="Rotation Shortcut")
        if self.enable_rotation_shortcut:
            row = col.row(align=True)
            row.prop(self, "key_shortcut_rotation", text="")
            row.separator()
            self.draw_modifier_buttons(row, "use_ctrl_rotation", "use_alt_rotation", "use_shift_rotation")
        
        ## Display settings
        # layout.separator()
        layout.label(text="Display:") # icon='RESTRICT_VIEW_OFF'
        col = layout.column()
        # col.prop(self, "use_hints")
        col.prop(self, "use_shortcut_ui_display")

    def draw_modifier_buttons(self, layout, ctrl_prop, alt_prop, shift_prop):
        for prop in [ctrl_prop, alt_prop, shift_prop]:
            layout.prop(self, prop, toggle=True)


def register():
    bpy.utils.register_class(SimpleAnimationPreferences)
    register_shortcuts()

def unregister():
    unregister_shortcuts()
    bpy.utils.unregister_class(SimpleAnimationPreferences)