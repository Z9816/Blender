import bpy
from mathutils import Vector
from .constants import CURVE_NAME

# Mapping of rotation modes to data_path
ROTATION_MODE_MAP = {
    'ZYX': 'rotation_euler',
    'ZXY': 'rotation_euler',
    'YZX': 'rotation_euler',
    'YXZ': 'rotation_euler',
    'XZY': 'rotation_euler',
    'XYZ': 'rotation_euler',
    'QUATERNION': 'rotation_quaternion',
    'AXIS_ANGLE': 'rotation_axis_angle'
}

def get_prefs():
    return bpy.context.preferences.addons[__package__].preferences

def set_keyframe(target, transform, frame) -> bool:
    '''simple keyframe insertion, pass object or bone, a transform channel name and a frame number
    transform (str): 'location', 'rotation' (or 'scale' not implemented yet)
    frame: frame number where to add the keyframes
    '''
    if not target:
        return False

    data_path = ROTATION_MODE_MAP[target.rotation_mode] if transform == 'rotation' else 'location'
    target.keyframe_insert(data_path, index=-1, frame=frame)
    ## Can use INSERTKEY_NEEDED options to avoid keying unaffected channels (but more predictable to key all)
    ## Default: keytype='KEYFRAME'
    
    return True

down = Vector((0,0,-1))

def apply_ops_rotation(source_vec, target_vec, pivot_location=None):
    '''Apply a rotation between two vectors using blender operators'''
    cursor = bpy.context.scene.cursor
    init_cursor_matrix = cursor.matrix.copy()

    cross = source_vec.cross(target_vec)
    angle = source_vec.angle(target_vec)

    ## Set rotation on 3D cursor to define axis with rotate operator
    rotate_to_cross = down.rotation_difference(cross)
    cursor.matrix = rotate_to_cross.to_matrix().to_4x4()
    
    if pivot_location is not None:
        cursor.location = pivot_location

    bpy.ops.transform.rotate('EXEC_DEFAULT',
        value=angle,
        #orient_axis='Z', # ('X', 'Y', 'Z')
        orient_type='CURSOR',
        #orient_matrix=((0, 0, 0), (0, 0, 0), (0, 0, 0)),
        orient_matrix_type='CURSOR',
        # constraint_axis=(False, False, False)
        use_proportional_edit=False,
        snap=False,
        # center_override=(0, 0, 0), ## Center override to define another pivot 
        # use_accurate=False
    )

    ## Restore cursor matrix
    cursor.matrix = init_cursor_matrix

class attr_set():
    '''get-set for context manager
    Receive a list of tuple [(data_path, "attribute" [, wanted value)] ]
    entering with-statement : Store existing values, assign wanted value (if any)
    exiting with-statement: Restore values to their old values in reverse order
    '''

    def __init__(self, attrib_list):
        self.store = []
        # item = (prop, attr, [new_val])
        for item in attrib_list:
            prop, attr = item[:2]
            self.store.append( (prop, attr, getattr(prop, attr)) )
            if len(item) >= 3:
                setattr(prop, attr, item[2])

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        for prop, attr, old_val in reversed(self.store):
            setattr(prop, attr, old_val)

def get_position_and_axis_direction(target):
    '''Get world position and local direction axis of object or bone
    return 4 vector: loc, x, y, z (1 position, 3 for axis directions)'''
    if isinstance(target, bpy.types.PoseBone):
        armature = target.id_data
        matrix = armature.matrix_world @ target.matrix
    else:
        matrix = target.matrix_world
    x = Vector((1,0,0))
    y = Vector((0,1,0))
    z = Vector((0,0,1))
    x.rotate(matrix)
    y.rotate(matrix)
    z.rotate(matrix)
    return matrix.to_translation(), (x, y, z)

## -- Annotation functions --

def set_active_annotation_opacity(opacity=1.0, context=None):
    '''Set active annotation opacity'''
    if context is None:
        context = bpy.context

    annotation = context.annotation_data
    if bpy.app.version >= (4, 3, 0):
        if isinstance(annotation, bpy.types.GreasePencil):
            # under gpv3 annotation type is GreasePencil
            if annotation.layers.active_index >= 0:
                layer = annotation.layers[annotation.layers.active_index]
                layer.annotation_opacity = opacity
    else:
        if annotation.layers.active:
            annotation.layers.active.opacity = opacity

def curve_exists_poll(context):
    '''Check if a curve trajectory exists in current scene'''
    return context.scene.objects.get(CURVE_NAME)

def active_annotation_frame_poll(context):
    return context.annotation_data\
        and context.annotation_data.layers[context.annotation_data.layers.active_index].active_frame

def remove_active_annotation(context):
    context = context or bpy.context
    if active_annotation_frame_poll(context):
        ad = context.annotation_data
        active_layer = ad.layers[ad.layers.active_index]
        active_layer.frames.remove(active_layer.active_frame)

## -- Debug functions --

def create_curve_from_points(points, collection_name="Animation_Debug_Local_Points"):
    # Create or get the collection for debug objects
    if collection_name in bpy.data.collections:
        debug_collection = bpy.data.collections[collection_name]
    else:
        debug_collection = bpy.data.collections.new(collection_name)
        bpy.context.scene.collection.children.link(debug_collection)

    # Create an empty for each intersection point
    # for idx, point in enumerate(intersection_points):
    #     empty = bpy.data.objects.new(f"Debug_Empty_{idx}", None)
    #     empty.location = point
    #     empty.scale = (0.05, 0.05, 0.05)
    #     debug_collection.objects.link(empty)

    # Create a NURBS curve through the intersection points
    curve_data = bpy.data.curves.new(name="Debug_Trajectory_Curve", type='CURVE')
    curve_data.dimensions = '3D'
    spline = curve_data.splines.new('POLY') # NURBS
    spline.points.add(len(points) - 1)
    spline.order_u = 2
    spline.use_endpoint_u = True

    for i,point in enumerate(points):
        # print(f"curve {point}")
        spline.points[i].co = (point[0], point[1], point[2], 1.0)  # The fourth value is the weight for NURBS/POLY

    curve_object = bpy.data.objects.new("Debug_Trajectory_Curve_Object", curve_data)

    debug_collection.objects.link(curve_object)


def empty_at(pos, name='Empty', type='PLAIN_AXES', size=0.05, show_name=False, link=True):
    '''
    Create an empty at given Vector3 position.
    pos (Vector3): position 
    name (str, default Empty): name of the empty object
    type (str, default 'PLAIN_AXES'): options in 'PLAIN_AXES','ARROWS','SINGLE_ARROW','CIRCLE','CUBE','SPHERE','CONE','IMAGE'
    size (int, default 1.0): Size of the empty
    link (Bool,default True): Link to active collection
    show_name (Bool, default False): Show name object
    i.e : empty_at((0,0,1), 'ARROWS', 2) creates "Empty" at Z+1, of type gyzmo and size 2
    '''
    
    mire = bpy.data.objects.get(name)
    if not mire:
        mire = bpy.data.objects.new(name, None)
        if link:
            bpy.context.collection.objects.link(mire)
    mire.empty_display_type = type
    mire.empty_display_size = size
    mire.location = pos
    mire.show_name = show_name
    return mire

def create_emptys_from_list(points, prefix="L_", show_name=False):
    for i, p in enumerate(points):
        empty_at(p, f"{prefix}{i:02d}", show_name=show_name)
